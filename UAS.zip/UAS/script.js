// Nexus Wellness - Campaign Script

// --- LOCAL STORAGE DATA CONTROLLER ---
const DB_VERSION = "v1.2";
const STORAGE_KEYS = {
    PAGEVIEWS: `mlbb_wellness_views_${DB_VERSION}`,
    QUIZ_TAKEN: `mlbb_wellness_quizzes_${DB_VERSION}`,
    QUIZ_TOTAL_SCORE: `mlbb_wellness_quiz_score_${DB_VERSION}`,
    FEEDBACK: `mlbb_wellness_feedback_${DB_VERSION}`,
    PRE_TEST: `mlbb_wellness_pretest_${DB_VERSION}`,
    POST_TEST: `mlbb_wellness_posttest_${DB_VERSION}`
};

// Seed feedback data for realism in report if local storage is empty
const defaultFeedback = [
    { name: "Andi S.", ui: 5, content: 5, comment: "Sangat membantu untuk merefleksikan kebiasaan mabar saya. Fitur kalkulator waktu bener-bener bikin mata melek!" },
    { name: "Rian_Gamer", ui: 4, content: 5, comment: "Kuisnya relevan banget sama anak ML. Kemarin sempat stuck di Legend terus emosi. Setelah baca smart habits, saya putuskan rehat kalau lose streak." },
    { name: "Kezia Olivia", ui: 5, content: 4, comment: "Desain websitenya futuristik dan modern, penjelasannya mudah dipahami. Artikel FOMO sangat mewakili perasaan saya yang pengen beli skin terus." },
    { name: "Dosen_Tester", ui: 5, content: 5, comment: "Kampanye cyberpsychology yang luar biasa. Sangat edukatif bagi mahasiswa TI/SI yang rentan screen time tinggi." }
];

// Initialize database
function initLocalStorage() {
    // Page Views
    let views = localStorage.getItem(STORAGE_KEYS.PAGEVIEWS);
    if (!views) {
        views = Math.floor(Math.random() * 400) + 800; // Simulated base
    }
    views = parseInt(views) + 1; // Increment on load
    localStorage.setItem(STORAGE_KEYS.PAGEVIEWS, views);

    // Quiz Counts
    if (!localStorage.getItem(STORAGE_KEYS.QUIZ_TAKEN)) {
        localStorage.setItem(STORAGE_KEYS.QUIZ_TAKEN, Math.floor(Math.random() * 50) + 100);
    }
    if (!localStorage.getItem(STORAGE_KEYS.QUIZ_TOTAL_SCORE)) {
        localStorage.setItem(STORAGE_KEYS.QUIZ_TOTAL_SCORE, Math.floor(Math.random() * 500) + 1000);
    }

    // Feedback list
    if (!localStorage.getItem(STORAGE_KEYS.FEEDBACK)) {
        localStorage.setItem(STORAGE_KEYS.FEEDBACK, JSON.stringify(defaultFeedback));
    }
}

initLocalStorage();

// --- STATE MANAGEMENT ---
const state = {
    quizAnswers: Array(10).fill(null),
    currentQuizStep: 0,
    preTestCompleted: localStorage.getItem(STORAGE_KEYS.PRE_TEST) ? true : false,
    postTestCompleted: localStorage.getItem(STORAGE_KEYS.POST_TEST) ? true : false,
    preTestScore: parseInt(localStorage.getItem(STORAGE_KEYS.PRE_TEST)) || 0,
    postTestScore: parseInt(localStorage.getItem(STORAGE_KEYS.POST_TEST)) || 0
};

// --- DATA DICTIONARIES ---

// Self-Check Quiz Questions
const quizQuestions = [
    {
        category: "Penarikan Diri (Withdrawal)",
        question: "Apakah Anda sering merasa gelisah, cemas, atau marah saat tidak bisa bermain Mobile Legends (karena sinyal buruk, kuota habis, atau saat harus beraktivitas)?",
        options: [
            { text: "Jarang / Tidak Pernah", score: 0 },
            { text: "Kadang-kadang", score: 1 },
            { text: "Sering / Selalu", score: 2 }
        ]
    },
    {
        category: "Toleransi (Tolerance)",
        question: "Apakah waktu bermain Mobile Legends Anda terus bertambah dari hari ke hari demi mendapatkan kepuasan atau mengejar tier rank tertentu?",
        options: [
            { text: "Jarang / Tidak Pernah", score: 0 },
            { text: "Kadang-kadang", score: 1 },
            { text: "Sering / Selalu", score: 2 }
        ]
    },
    {
        category: "Kontrol Diri (Relapse)",
        question: "Apakah Anda sering gagal membatasi waktu bermain Mobile Legends meskipun sudah berulang kali berjanji pada diri sendiri untuk membatasinya?",
        options: [
            { text: "Jarang / Tidak Pernah", score: 0 },
            { text: "Kadang-kadang", score: 1 },
            { text: "Sering / Selalu", score: 2 }
        ]
    },
    {
        category: "Pengalihan Minat (Displacement)",
        question: "Apakah Anda kehilangan minat pada hobi lain, olahraga, atau sosialisasi di dunia nyata sejak aktif bermain Mobile Legends?",
        options: [
            { text: "Jarang / Tidak Pernah", score: 0 },
            { text: "Kadang-kadang", score: 1 },
            { text: "Sering / Selalu", score: 2 }
        ]
    },
    {
        category: "Konflik (Conflict)",
        question: "Apakah bermain Mobile Legends menyebabkan masalah dalam hubungan sosial Anda (bertengkar dengan orang tua/teman/pacar) atau mengganggu kehidupan akademik Anda?",
        options: [
            { text: "Jarang / Tidak Pernah", score: 0 },
            { text: "Kadang-kadang", score: 1 },
            { text: "Sering / Selalu", score: 2 }
        ]
    },
    {
        category: "Kebohongan (Deception)",
        question: "Apakah Anda sering berbohong kepada keluarga, dosen, atau teman mengenai durasi waktu yang Anda habiskan untuk bermain Mobile Legends?",
        options: [
            { text: "Jarang / Tidak Pernah", score: 0 },
            { text: "Kadang-kadang", score: 1 },
            { text: "Sering / Selalu", score: 2 }
        ]
    },
    {
        category: "Pelarian (Escape)",
        question: "Apakah Anda menjadikan Mobile Legends sebagai cara utama untuk melarikan diri dari stres tugas kuliah, kecemasan, atau masalah kehidupan nyata?",
        options: [
            { text: "Jarang / Tidak Pernah", score: 0 },
            { text: "Kadang-kadang", score: 1 },
            { text: "Sering / Selalu", score: 2 }
        ]
    },
    {
        category: "Dampak Fisik (Health Impact)",
        question: "Apakah Anda sering begadang demi push rank hingga mengganggu pola tidur Anda dan membuat Anda lelah di pagi hari?",
        options: [
            { text: "Jarang / Tidak Pernah", score: 0 },
            { text: "Kadang-kadang", score: 1 },
            { text: "Sering / Selalu", score: 2 }
        ]
    },
    {
        category: "Pengabaian (Neglect)",
        question: "Apakah Anda sering menunda atau mengabaikan tugas kuliah, pekerjaan rumah, atau kebersihan diri demi menyelesaikan pertandingan/mabar?",
        options: [
            { text: "Jarang / Tidak Pernah", score: 0 },
            { text: "Kadang-kadang", score: 1 },
            { text: "Sering / Selalu", score: 2 }
        ]
    },
    {
        category: "Kehilangan Kendali Emosi (Chasing Losses)",
        question: "Apakah Anda sering merasa emosional saat mengalami kekalahan (lose streak) dan terus bermain ('satu game lagi') demi membalas kekalahan meskipun emosi Anda sudah kacau?",
        options: [
            { text: "Jarang / Tidak Pernah", score: 0 },
            { text: "Kadang-kadang", score: 1 },
            { text: "Sering / Selalu", score: 2 }
        ]
    }
];

// Rank Stress Diagnosis Data (Cyberpsychology Domain Mapping)
const rankStressData = {
    casual: {
        title: "Warrior - Grandmaster (Casual Tier)",
        stressLevel: "Rendah (Low Stress)",
        stressClass: "stress-low",
        description: "Pada tier ini, tingkat stres emosional cenderung sangat rendah. Permainan masih terasa rekreasi dan kasual. Motivasi utama biasanya adalah kesenangan murni atau mengeksplorasi hero baru. Namun, pada tahap inilah kebiasaan dan dopamin hook awal mulai terbentuk.",
        cognitiveLoad: "Rendah. Pola permainan santai, minim taktik makro yang rumit, dan reaksi teammates yang tidak terlalu menuntut.",
        advice: "Pertahankan mindset bermain santai ini. Jangan jadikan kemenangan sebagai satu-satunya tolak ukur kesenangan. Waspadai dorongan awal untuk membeli skin kosmetik yang memicu FOMO."
    },
    epic: {
        title: "Epic ('Epic Hell' / Tier Abadi)",
        stressLevel: "Sangat Tinggi (Volatile)",
        stressClass: "stress-high",
        description: "Dikenal di komunitas sebagai 'Epic Hell' karena tingginya keragaman skill pemain dan ketidakstabilan emosi tim. Di tier ini, frustrasi kognitif memuncak akibat perilaku teammates yang toxic, egois (seperti berebut hero hyper/core), atau sengaja kalah (troll). Ini memicu bias kognitif 'Self-Serving Bias' (menyalahkan orang lain atas kegagalan).",
        cognitiveLoad: "Sangat Tinggi. Beban mental bertambah akibat kemarahan (rage-quitting), toxic chat, dan perjuangan mekanik yang tidak seimbang.",
        advice: "Gunakan fitur <strong>Mute Chat</strong> sejak awal draf pick. Jangan membalas chat toxic karena akan merusak fokus motorik Anda. Mabar hanya dengan teman dekat (duo/trio) untuk mengurangi risiko mendapatkan pemain toxic secara acak."
    },
    legend: {
        title: "Legend (Demotion Anxiety)",
        stressLevel: "Tinggi (High Anxiety)",
        stressClass: "stress-high",
        description: "Tier transisi menuju Mythic ini dicirikan oleh 'kecemasan penurunan tingkat' (demotion anxiety). Ketakutan kehilangan bintang dan turun kembali ke Epic membuat pemain sangat tegang. Rasa cemas ini memicu obsesi bermain berlebihan ('just one more game to rank up') yang sering berujung pada lose streak panjang dan insomnia kronis.",
        cognitiveLoad: "Tinggi. Fokus taktis sangat dibutuhkan karena gameplay mulai ketat, namun emosi yang tegang mengganggu pengambilan keputusan makro.",
        advice: "Terapkan secara ketat <strong>2-Loss Stop Rule</strong>. Begitu kalah 2 kali beruntun, langsung tutup game Anda. Jangan paksakan bermain di malam hari demi mengejar bintang yang hilang karena konsentrasi Anda sedang menurun drastis."
    },
    mythic: {
        title: "Mythic (Ego & Social Status)",
        stressLevel: "Sedang - Tinggi (Prestige)",
        stressClass: "stress-medium",
        description: "Pada tier prestisius ini, motivasi bergeser dari sekadar hiburan menjadi pembuktian identitas sosial dan ego. Pemain merasa harga diri dan status sosial mereka dalam pergaulan diwakili oleh tier Mythic. FOMO (Fear of Missing Out) sangat tinggi jika teman sebaya berada di tier yang lebih tinggi.",
        cognitiveLoad: "Tinggi. Memerlukan analisis draf pick yang matang, counter-pick hero, dan koordinasi makro peta yang ketat.",
        advice: "Ingatlah bahwa tier game Anda tidak mendefinisikan nilai akademis atau kapabilitas diri Anda di dunia nyata. Jangan korbankan tugas kuliah atau waktu tidur hanya demi poin Mythic Placement yang nilainya fluktuatif."
    },
    glory: {
        title: "Mythical Glory & Above (Hardcore Addicts)",
        stressLevel: "Ekstrem (Peak Loss Aversion)",
        stressClass: "stress-high",
        description: "Pemain di tier ini tergolong hardcore gamer. Stres didominasi oleh ketakutan ekstrem kehilangan poin (Peak Loss Aversion). Kehilangan 15-20 poin terasa sangat menyakitkan dibanding kepuasan memenangkan game. Risiko adiksi klinis, Carpal Tunnel Syndrome, serta pengabaian tanggung jawab akademik dan sosial berada di level tertinggi.",
        cognitiveLoad: "Ekstrem. Membutuhkan konsentrasi mikro dan makro absolut selama 15-25 menit per game. Koordinasi suara aktif dan pemahaman patch note sangat krusial.",
        advice: "Anda sangat membutuhkan <strong>Detoks Digital 48 Jam</strong> secara berkala. Jadwalkan waktu rehat total dari game untuk memulihkan sendi tangan dan mengistirahatkan saraf kognitif Anda dari paparan dopamin ekstrem."
    }
};

// Blog Article Detailed Content
const blogArticles = {
    1: {
        title: "Mengapa Kita Takut Kehilangan Bintang? Membedah FOMO di MLBB",
        category: "Psikologi",
        date: "24 Mei 2026",
        content: `
            <p>Bagi jutaan pemain Mobile Legends: Bang Bang (MLBB), ikon bintang kecil di tier Epic, Legend, atau Mythic bukan sekadar elemen visual. Kehilangan satu bintang akibat kekalahan sering kali memicu respons emosional yang intens: amarah (rage-quit), kecemasan, hingga suasana hati yang buruk sepanjang hari. Fenomena ini erat kaitannya dengan bias psikologis yang dikenal sebagai <strong>Loss Aversion</strong> dan <strong>FOMO (Fear of Missing Out)</strong>.</p>
            
            <h4>Mengapa Kehilangan Bintang Terasa Begitu Menyakitkan?</h4>
            <p>Secara psikologis, manusia terprogram untuk membenci kekalahan dua kali lebih kuat dibandingkan kesenangan saat menang. Dalam MLBB, draf pick yang kacau, rekan tim toxic, atau lag jaringan sering dianggap sebagai ancaman langsung terhadap jerih payah investasi waktu kita. Status sosial di lingkungan pertemanan (misalnya kelompok mabar kampus) juga bergantung pada tier rank. Ketika rank kita turun, kita merasa kehilangan validasi sosial, memicu rasa minder dan cemas tertinggal dari teman sebaya.</p>
            
            <h4>Efek Dopamin Loop</h4>
            <p>Sistem pencocokan lawan (matchmaking) diatur menggunakan algoritma yang mirip dengan mesin judi kasino. Kemenangan yang tidak terduga melepaskan dopamin (neurotransmiter kesenangan) dalam otak. Saat kalah, otak kita secara naluriah menuntut dopamin instan untuk 'memperbaiki' suasana hati. Akibatnya, kita masuk ke dalam siklus merusak: terus menekan tombol matchmaking meskipun sudah kelelahan dan emosional, sebuah fenomena yang disebut <em>Chasing Losses</em>.</p>
            
            <h4>Cara Mengatasi Stress Rank MLBB:</h4>
            <ul>
                <li><strong>Ganti Mindset:</strong> Fokuslah pada peningkatan mekanik atau makro permainan Anda sendiri, bukan pada naik turunnya bintang virtual.</li>
                <li><strong>Terapkan Batasan Ketat:</strong> Berjanjilah untuk mematikan game setelah kalah dua kali berturut-turut. Kehilangan bintang di game ketiga hampir pasti terjadi karena fokus Anda sudah rusak.</li>
                <li><strong>Matikan Fitur Chat:</strong> Fokus pada gameplay Anda. 90% obrolan chat di tier bawah adalah toxic dan hanya memicu stres emosional yang tidak perlu.</li>
            </ul>
        `
    },
    2: {
        title: "Panduan Praktis Detoks Digital 24 Jam Tanpa MLBB",
        category: "Digital Wellness",
        date: "20 Mei 2026",
        content: `
            <p>Apakah Anda merasa smartphone Anda seperti menempel di tangan? Apakah notifikasi Mobile Legends atau ajakan mabar dari WhatsApp grup membuat Anda tidak bisa fokus belajar lebih dari 15 menit? Jika ya, otak Anda mungkin sedang mengalami jenuh digital (digital overload). Detoks digital 24 jam adalah langkah intervensi mandiri untuk merestart sistem reward di otak Anda.</p>
            
            <h4>Apa yang Terjadi pada Otak Saat Detoks Digital?</h4>
            <p>Saat Anda bermain game secara intens, otak dibombardir oleh dopamin kadar tinggi. Kehidupan nyata (seperti membaca buku, mendengarkan kuliah, atau mengobrol santai) terasa membosankan karena tingkat rangsangannya jauh lebih rendah. Dengan menjauh dari game dan layar selama 24 jam, sensitivitas reseptor dopamin Anda akan mulai pulih secara perlahan. Aktivitas sederhana akan kembali terasa menarik.</p>
            
            <h4>Langkah-Langkah Sukses Detoks 24 Jam:</h4>
            <ol>
                <li><strong>Beritahu Teman Mabar Anda:</strong> Sampaikan bahwa Anda sedang melakukan eksperimen detoks digital selama sehari agar mereka tidak meneror Anda dengan ajakan mabar.</li>
                <li><strong>Sembunyikan Aplikasi:</strong> Pindahkan ikon Mobile Legends ke dalam folder terdalam di HP Anda, atau hapus instalannya (uninstall) untuk sementara. Menghilangkan pemicu visual (visual cue) sangat efektif meredam keinginan bermain.</li>
                <li><strong>Ganti dengan Kegiatan Fisik:</strong> Otak Anda membutuhkan pengganti aktivitas. Jadwalkan olahraga, membaca buku fisik, merapikan kamar, atau bertemu teman secara tatap muka tanpa memegang gawai.</li>
                <li><strong>Gunakan Fitur Do Not Disturb (DND):</strong> Matikan seluruh notifikasi yang tidak mendesak demi ketenangan pikiran.</li>
            </ol>
            
            <h4>Manfaat yang Akan Anda Rasakan:</h4>
            <p>Setelah melewati 24 jam, Anda akan merasakan peningkatan kualitas tidur, fokus belajar yang lebih tajam, berkurangnya ketegangan leher/bahu, dan kesadaran bahwa hidup di luar Land of Dawn ternyata sangat menyenangkan.</p>
        `
    },
    3: {
        title: "Tips Menjaga IPK Tetap Stabil Bagi Pemain Aktif MLBB",
        category: "Tips Praktis",
        date: "15 Mei 2026",
        content: `
            <p>Menjadi mahasiswa berprestasi sekaligus aktif bermain Mobile Legends bukanlah hal yang mustahil. Banyak pro player atau gamer kasual yang berhasil mempertahankan indeks prestasi kumulatif (IPK) di atas 3.5. Kuncinya bukan pada menghentikan hobi Anda sepenuhnya, melainkan pada manajemen waktu yang presisi dan disiplin diri.</p>
            
            <h4>Teknik Pomodoro untuk Gamer</h4>
            <p>Sebelum membuka aplikasi Mobile Legends, terapkan teknik belajar Pomodoro: Belajar fokus selama 25 menit, diikuti istirahat 5 menit. Ulangi siklus ini 4 kali, kemudian berikan diri Anda reward bermain Mobile Legends selama 1 game (sekitar 15-20 menit) sebagai bentuk istirahat panjang. Ini melatih otak mengaitkan kerja keras dengan kesenangan game secara proporsional.</p>
            
            <h4>Manajemen Waktu: Blokir Waktu Bermain</h4>
            <p>Tentukan 'Jam Malam Game' Anda. Misalnya, Anda hanya diizinkan bermain Mobile Legends antara jam 20.00 hingga 21.30. Di luar jam tersebut, gawai Anda harus difokuskan untuk produktivitas atau diatur dalam mode belajar. Jangan biarkan game masuk ke celah waktu luang di sela-sela kelas kuliah.</p>
            
            <h4>Aturan Emas Mahasiswa Gamer Cerdas:</h4>
            <ul>
                <li><strong>Selesaikan Tugas Kuliah di Kampus:</strong> Jangan tunda tugas kuliah sampai pulang ke kos/rumah. Selesaikan tugas di perpustakaan atau area kampus sesaat setelah kelas berakhir agar malam hari Anda benar-benar bebas dari beban akademis.</li>
                <li><strong>Tidur yang Cukup:</strong> Jangan pernah memotong waktu tidur demi push rank. Kurang tidur terbukti menurunkan kemampuan kognitif otak hingga 30% pada esok harinya saat ujian atau menerima materi kuliah.</li>
                <li><strong>Pilih Teman Mabar yang Suportif:</strong> Mabar dengan teman kuliah yang juga peduli pada tugas akademis jauh lebih baik daripada mabar dengan rekan toxic yang meremehkan perkuliahan.</li>
            </ul>
        `
    },
    4: {
        title: "Dopamin & Adiksi Game: Apa Kata Ilmu Saraf?",
        category: "Psikologi",
        date: "28 Mei 2026",
        content: `
            <p>Di balik kesenangan bermain Mobile Legends, terdapat proses biokimia yang sangat kompleks di dalam otak Anda. Penelitian neuroimaging terkini mengungkapkan bahwa pola aktivasi otak pada pemain yang kecanduan game memiliki kemiripan mengejutkan dengan pola pada individu yang mengalami kecanduan zat adiktif. Inilah penjelasan ilmiah mengapa kita terus tergoda bermain "satu game lagi".</p>

            <h4>Sistem Reward Otak & Dopamin</h4>
            <p>Ketika Anda menang dalam satu sesi Mobile Legends, otak Anda melepaskan dopamin — neurotransmiter yang bertanggung jawab atas perasaan senang dan puas. Yang membuat game MOBA seperti MLBB sangat adiktif adalah penerapan <em>variable-ratio reinforcement schedule</em>: hadiah (kemenangan) datang secara acak dan tidak terprediksi, persis seperti mesin slot kasino. Pola reinforcement acak ini terbukti secara ilmiah menjadi yang paling kuat dalam membentuk perilaku berulang.</p>

            <h4>Reward Deficiency Syndrome (RDS)</h4>
            <p>Seiring waktu, otak yang terus-menerus mendapat stimulasi dopamin tinggi dari game akan mengalami <em>desensitisasi reseptor</em>. Akibatnya, kegiatan sehari-hari yang "biasa" — seperti membaca, belajar, atau mengobrol — tidak lagi mampu memicu respons dopamin yang cukup. Fenomena ini dikenal sebagai Reward Deficiency Syndrome (RDS). Inilah mengapa mahasiswa yang kecanduan game sering merasa bosan dan kehilangan motivasi belajar.</p>

            <h4>Bukti Neuroimaging: Otak Gamer Adiksi vs Normal</h4>
            <p>Studi menggunakan fMRI menunjukkan bahwa individu dengan Internet Gaming Disorder (IGD) memiliki aktivasi ventral striatum (pusat reward otak) yang lebih tinggi saat terpapar stimulus game dibanding kelompok kontrol — pola yang identik dengan yang ditemukan pada pecandu kokain dan alkohol. Selain itu, ditemukan pula penurunan volume materi abu-abu di area prefrontal cortex, yaitu wilayah otak yang mengatur kontrol impuls dan pengambilan keputusan rasional.</p>

            <h4>Implikasi bagi Pemain MLBB</h4>
            <p>Pemahaman ini penting: adiksi game bukan sekadar soal "kurang disiplin" atau "malas". Ini adalah respons neurologis nyata yang memerlukan pendekatan terstruktur untuk dipulihkan. Langkah pertama adalah membatasi paparan stimulus game secara bertahap (bukan berhenti total mendadak yang memicu withdrawal), sambil secara aktif membangun kebiasaan yang juga merangsang sistem reward secara sehat, seperti olahraga, musik, atau pencapaian akademis.</p>

            <div class="journal-references">
                <h4>📚 Referensi Jurnal Ilmiah</h4>
                <ul class="journal-list">
                    <li>
                        <span class="journal-badge">Neuroscience • 2024</span>
                        <strong>Zhang, M., et al. (2024).</strong> Outcome assessment of different reward stimuli in Internet gaming disorder by event-related potentials. <em>PLOS ONE</em>. 
                        <a href="https://pmc.ncbi.nlm.nih.gov/articles/PMC11268701/" target="_blank" rel="noopener" class="journal-link">🔗 Baca Jurnal</a>
                    </li>
                    <li>
                        <span class="journal-badge">Neurosci • PMC</span>
                        <strong>Fauth-Bühler, M., & Mann, K. (2014).</strong> Linking Online Gaming and Addictive Behavior: Converging Evidence for a General Reward Deficiency in Frequent Online Gamers. <em>Frontiers in Human Neuroscience</em>.
                        <a href="https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4226163/" target="_blank" rel="noopener" class="journal-link">🔗 Baca Jurnal</a>
                    </li>
                    <li>
                        <span class="journal-badge">Psychiatry • 2023</span>
                        <strong>Király, O., Koncz, P., Griffiths, M., & Demetrovics, Z. (2023).</strong> Gaming disorder: A summary of its characteristics and aetiology. <em>Comprehensive Psychiatry, 122</em>, 152376.
                        <a href="https://www.frontiersin.org/journals/psychiatry/articles/10.3389/fpsyt.2024.1423785/full" target="_blank" rel="noopener" class="journal-link">🔗 Baca Jurnal</a>
                    </li>
                </ul>
            </div>
        `
    },
    5: {
        title: "Gaming Disorder di Indonesia: Fakta & Data Terbaru 2024–2025",
        category: "Digital Wellness",
        date: "26 Mei 2026",
        content: `
            <p>Indonesia bukan sekadar pasar game terbesar di Asia Tenggara — kita juga menghadapi krisis kesehatan digital yang diam-diam tumbuh di kalangan generasi muda. Berbagai studi terbaru mengungkap data mengkhawatirkan tentang prevalensi gangguan gaming (gaming disorder) di Indonesia, khususnya pada remaja dan mahasiswa yang merupakan basis pemain utama Mobile Legends.</p>

            <h4>Fakta Konsumsi Game di Indonesia</h4>
            <p>Menurut laporan State of Mobile 2024 (Data.AI), belanja konsumen game mobile di Indonesia mencapai US$410 juta (sekitar Rp6,3 triliun) sepanjang 2023. Mobile Legends: Bang Bang menjadi game mobile dengan pengeluaran pengguna terbesar di Indonesia, melampaui semua kompetitor. Mayoritas konsumen game online bermain lebih dari 4 jam per hari — angka yang secara klinis sudah masuk zona berisiko tinggi.</p>

            <h4>Data Prevalensi Gaming Disorder pada Remaja Indonesia</h4>
            <p>Sebuah studi lintas-lokasi (multi-settings cross-sectional) yang dilakukan oleh Satria et al. (2024) pada remaja di berbagai wilayah Indonesia menemukan prevalensi gaming disorder yang signifikan. Remaja dengan akses internet tidak terbatas dan tekanan akademis tinggi menunjukkan gejala IGD yang lebih berat. Studi di Aceh oleh Martina et al. (2024) juga mengonfirmasi tingginya kasus Internet Gaming Disorder pada remaja di pedesaan, menunjukkan bahwa fenomena ini tidak terbatas di perkotaan saja.</p>

            <h4>Siapa yang Paling Rentan?</h4>
            <p>Penelitian konsisten menunjukkan beberapa faktor risiko utama pada konteks Indonesia: tekanan akademis yang tinggi (mencari pelarian lewat game), pemenuhan kebutuhan sosial melalui game (terutama pada individu yang merasa kesepian atau sulit bergaul di dunia nyata), serta akses internet murah dan mudah yang menghilangkan hambatan bermain. Mahasiswa tahun pertama yang mengalami culture shock dunia perkuliahan teridentifikasi sebagai kelompok paling rentan.</p>

            <h4>Dampak pada Kualitas Tidur</h4>
            <p>Studi yang dipublikasikan di Jurnal Psikologi Teori dan Terapan (2024) menemukan korelasi signifikan antara adiksi game Mobile Legends dan buruknya kualitas tidur pada remaja Indonesia. Pemain yang mengalami adiksi cenderung tidur di atas jam 01.00 dini hari, mengalami insomnia, dan mengalami penurunan performa kognitif serta akademis yang terukur.</p>

            <div class="journal-references">
                <h4>📚 Referensi Jurnal Ilmiah</h4>
                <ul class="journal-list">
                    <li>
                        <span class="journal-badge">Indonesia • Acta Biomed 2024</span>
                        <strong>Satria, B., Mustanir, M., Oktari, R.S., & Marthoenis, M. (2024).</strong> Gaming disorder among adolescent in Indonesia: A multi-settings cross-sectional study. <em>Acta Biomedica Atenei Parmensis, 95</em>(5), e2024147.
                        <a href="https://www.mattioli1885journals.com/index.php/actabiomedica/article/view/15826" target="_blank" rel="noopener" class="journal-link">🔗 Baca Jurnal</a>
                    </li>
                    <li>
                        <span class="journal-badge">Indonesia • JPTT 2024</span>
                        <strong>Amanah, S., et al. (2024).</strong> The Relationship Between Addiction to the Online Game Mobile Legends Bang-Bang (MLBB) and Sleep Quality in Teenagers. <em>Jurnal Psikologi Teori dan Terapan</em>.
                        <a href="https://journal.unesa.ac.id/index.php/jptt/article/view/29952" target="_blank" rel="noopener" class="journal-link">🔗 Baca Jurnal</a>
                    </li>
                    <li>
                        <span class="journal-badge">Indonesia • JED 2025</span>
                        <strong>Airlangga, M.M., & Alfansi, L. (2025).</strong> Drivers of Mobile Game Addiction and Its Impact on Game Loyalty and In-App Purchase Intention Among Gen-Z in Indonesia. <em>Journal of Enterprise and Development (JED), 7</em>(2), 217–230.
                        <a href="https://journal.uinmataram.ac.id/index.php/jed/article/view/13120" target="_blank" rel="noopener" class="journal-link">🔗 Baca Jurnal</a>
                    </li>
                    <li>
                        <span class="journal-badge">Indonesia • IGD Aceh 2024</span>
                        <strong>Martina, M., et al. (2024).</strong> Internet Gaming Disorder among Rural Adolescents: A Cross-Sectional Study in Aceh, Indonesia. <em>Journal of Liaquat University of Medical & Health Sciences</em>, 100–104.
                        <a href="https://www.mattioli1885journals.com/index.php/actabiomedica/article/view/15826" target="_blank" rel="noopener" class="journal-link">🔗 Lihat Referensi</a>
                    </li>
                </ul>
            </div>
        `
    },
    6: {
        title: "CBT untuk Adiksi Game: Pendekatan Terbukti dari Praktisi Klinis",
        category: "Tips Praktis",
        date: "22 Mei 2026",
        content: `
            <p>Jika Anda atau orang terdekat mengalami gejala adiksi game yang sudah mengganggu kehidupan sehari-hari secara serius, langkah berikutnya bukan sekadar "kurangi main" — melainkan intervensi terstruktur bersama profesional. Cognitive Behavioral Therapy (CBT) saat ini menjadi pendekatan terapeutik yang paling banyak diteliti dan terbukti efektif dalam menangani Internet Gaming Disorder (IGD).</p>

            <h4>Apa itu CBT untuk Adiksi Game?</h4>
            <p>CBT adalah pendekatan psikoterapi terstruktur yang berfokus pada identifikasi dan restrukturisasi pola pikir serta perilaku maladaptif. Dalam konteks adiksi game, terapis CBT membantu klien mengenali <em>trigger</em> spesifik yang mendorong mereka bermain berlebihan (misalnya: stres, kesepian, kegagalan akademis), lalu membangun strategi koping yang lebih sehat sebagai penggantinya.</p>

            <h4>Bukti Efektivitas: Apa Kata Meta-Analisis?</h4>
            <p>Sebuah meta-analisis komprehensif yang diterbitkan di <em>Psychiatry Research</em> (2025) menganalisis 13 studi dengan total 1.115 partisipan. Hasilnya menunjukkan bahwa individu dengan gaming disorder yang menjalani CBT menunjukkan penurunan gejala adiksi yang signifikan dibanding kelompok kontrol (effect size g = 0.72). Systematic review terbaru mencakup 22 studi (2014–2025) yang dipublikasikan di PubMed Central juga mengonfirmasi CBT sebagai intervensi paling efektif, terutama saat dikombinasikan dengan latihan fisik atau mindfulness.</p>

            <h4>Apa yang Terjadi dalam Sesi CBT?</h4>
            <p>Sesi CBT untuk gaming disorder umumnya meliputi: (1) <strong>Psikoedukasi</strong> — memahami mekanisme adiksi dan dampaknya; (2) <strong>Monitoring diri</strong> — mencatat waktu bermain dan pemicunya; (3) <strong>Restrukturisasi kognitif</strong> — menantang keyakinan irasional seperti "kalau tidak push rank hari ini, saya akan gagal"; (4) <strong>Aktivasi perilaku</strong> — secara bertahap membangun aktivitas alternatif yang memuaskan; dan (5) <strong>Pencegahan relaps</strong> — strategi menghadapi situasi berisiko tinggi.</p>

            <h4>Mindfulness sebagai Pendekatan Pelengkap</h4>
            <p>Sebuah pendekatan inovatif terbaru dari <em>Journal of Medical Internet Research</em> (2025) memperkenalkan Mindfulness-Based Cognitive Therapy–Game (MBCT-G): sebuah program yang mengintegrasikan mindfulness dengan game sebagai medium terapeutik itu sendiri. Pendekatan ini mengakui bahwa gaming bukan musuh, melainkan perilaku yang perlu dikelola secara sadar.</p>

            <h4>Kapan Harus Mencari Bantuan Profesional?</h4>
            <p>Segera cari bantuan jika Anda mengalami: kegagalan berulang mengontrol waktu bermain meski sudah berusaha keras, dampak serius pada akademis atau hubungan sosial, gejala withdrawal fisik saat tidak bermain, atau penggunaan game sebagai satu-satunya mekanisme koping untuk mengatasi stres. Anda dapat menghubungi layanan konsultasi kesehatan jiwa Kemenkes RI di nomor <strong>119 ext 8</strong>.</p>

            <div class="journal-references">
                <h4>📚 Referensi Jurnal Ilmiah</h4>
                <ul class="journal-list">
                    <li>
                        <span class="journal-badge">Meta-Analisis • SciDirect 2025</span>
                        <strong>Dong, G., et al. (2025).</strong> Effects of cognitive behavioral therapy (CBT) on addictive symptoms in individuals with internet gaming disorders: A systematic review and meta-analysis. <em>Psychiatry Research</em>.
                        <a href="https://www.sciencedirect.com/science/article/abs/pii/S0165178125000745" target="_blank" rel="noopener" class="journal-link">🔗 Baca Jurnal</a>
                    </li>
                    <li>
                        <span class="journal-badge">Systematic Review • PMC 2025</span>
                        <strong>Effectiveness of Therapeutic Interventions in the Treatment of Internet Gaming Disorder (2025).</strong> Systematic review mencakup 22 studi (2014–2025) sesuai panduan PRISMA. <em>PubMed Central (PMC)</em>.
                        <a href="https://www.ncbi.nlm.nih.gov/pmc/articles/PMC12025817/" target="_blank" rel="noopener" class="journal-link">🔗 Baca Jurnal</a>
                    </li>
                    <li>
                        <span class="journal-badge">JMIR • 2025</span>
                        <strong>Mindfulness-Based Cognitive Therapy–Game (MBCT-G) (2025).</strong> An Ironic Way to Treat Internet Gaming Disorder. <em>Journal of Medical Internet Research, 27</em>, e65786.
                        <a href="https://www.jmir.org/2025/1/e65786" target="_blank" rel="noopener" class="journal-link">🔗 Baca Jurnal</a>
                    </li>
                    <li>
                        <span class="journal-badge">JMIR Protocol • 2024</span>
                        <strong>Bore, P., et al. (2024).</strong> Effectiveness and Acceptability of CBT and Family Therapy for Gaming Disorder. <em>JMIR Research Protocols</em>.
                        <a href="https://www.ncbi.nlm.nih.gov/pmc/articles/PMC11364953/" target="_blank" rel="noopener" class="journal-link">🔗 Baca Jurnal</a>
                    </li>
                </ul>
            </div>
        `
    }
};

// --- DOM SELECTIONS ---
document.addEventListener("DOMContentLoaded", () => {
    // Section snapping states
    let isAnimating = false;
    let currentSectionIndex = 0;
    const sections = Array.from(document.querySelectorAll("section, footer"));

    // Nav elements
    const navbar = document.querySelector(".navbar");
    const menuToggle = document.querySelector(".menu-toggle");
    const mobileMenu = document.querySelector(".mobile-menu-overlay");
    const navLinks = document.querySelectorAll(".nav-links a, .mobile-nav-links a");

    // Quiz elements
    const quizProgress = document.getElementById("quiz-progress");
    const quizStepText = document.getElementById("quiz-step-text");
    const quizCatText = document.getElementById("quiz-cat-text");
    const questionText = document.getElementById("question-text");
    const optionsContainer = document.getElementById("options-container");
    const prevBtn = document.getElementById("prev-btn");
    const nextBtn = document.getElementById("next-btn");
    const quizBody = document.getElementById("quiz-body");
    const quizFooter = document.getElementById("quiz-footer");
    const quizResults = document.getElementById("quiz-results");

    // Blog elements
    const filterButtons = document.querySelectorAll(".filter-btn");
    const blogCards = document.querySelectorAll(".blog-card");
    const blogModal = document.getElementById("blog-modal");
    const modalBody = document.getElementById("modal-article-body");

    // Survey elements
    const pretestBanner = document.getElementById("pretest-banner");
    const prePostForm = document.getElementById("prepost-survey-form");
    const surveyWidget = document.getElementById("survey-widget");
    const surveyStatusText = document.getElementById("survey-status-text");
    const surveySubmitBtn = document.getElementById("survey-submit-btn");
    const surveyCompletionBox = document.getElementById("survey-completion-box");
    const surveyPretestContainer = document.getElementById("survey-pretest-container");

    // Rating elements
    const uiStars = document.querySelectorAll("#ui-stars .star");
    const contentStars = document.querySelectorAll("#content-stars .star");
    const uiRatingInput = document.getElementById("eval-ui-rating");
    const contentRatingInput = document.getElementById("eval-content-rating");
    const evalForm = document.getElementById("uiux-evaluation-form");

    // --- NAVIGATION LOGIC ---
    // Sticky header
    window.addEventListener("scroll", () => {
        if (window.scrollY > 50) {
            navbar.classList.add("scrolled");
        } else {
            navbar.classList.remove("scrolled");
        }
    });

    // Mobile menu toggle
    if (menuToggle) {
        menuToggle.addEventListener("click", () => {
            menuToggle.classList.toggle("active");
            mobileMenu.classList.toggle("active");
        });
    }

    // Liquid smooth scroll helper
    function smoothScrollTo(targetPosition, duration) {
        const startPosition = window.pageYOffset || document.documentElement.scrollTop;
        const distance = targetPosition - startPosition;
        let startTime = null;

        function easeOutQuint(t) {
            // Smooth cubic ease — starts fast, decelerates gently into landing
            return 1 - Math.pow(1 - t, 3);
        }

        function animation(currentTime) {
            if (startTime === null) startTime = currentTime;
            const timeElapsed = currentTime - startTime;
            const progress = Math.min(timeElapsed / duration, 1);
            const ease = easeOutQuint(progress);
            
            window.scrollTo(0, startPosition + distance * ease);

            if (timeElapsed < duration) {
                requestAnimationFrame(animation);
            }
        }
        requestAnimationFrame(animation);
    }

    // Close mobile menu and smooth scroll when link is clicked
    navLinks.forEach(link => {
        link.addEventListener("click", (e) => {
            const targetId = link.getAttribute("href");
            if (!targetId || targetId === "#" || targetId.startsWith("http")) return;

            e.preventDefault();
            menuToggle.classList.remove("active");
            mobileMenu.classList.remove("active");

            const targetSection = document.querySelector(targetId);
            if (targetSection) {
                const targetY = targetSection.offsetTop;
                
                // Block snapping during custom nav scroll transition
                isAnimating = true;
                const secIndex = sections.indexOf(targetSection);
                if (secIndex !== -1) currentSectionIndex = secIndex;

                highlightActiveNav(targetId.replace("#", ""));

                smoothScrollTo(targetY, 1200);

                setTimeout(() => {
                    isAnimating = false;
                }, 1250);
            }
        });
    });

    // Active Section Highlighting — single source of truth
    function highlightActiveNav(sectionId) {
        document.querySelectorAll(".nav-links a").forEach(link => {
            link.classList.remove("active");
            if (sectionId && link.getAttribute("href") === `#${sectionId}`) {
                link.classList.add("active");
            }
        });
    }

    // Called on free scroll to keep nav in sync
    function highlightNavFromScroll() {
        const scrollPosition = window.scrollY + 80;
        const allSections = document.querySelectorAll("section");
        let activeId = null;
        allSections.forEach(section => {
            if (scrollPosition >= section.offsetTop) {
                activeId = section.getAttribute("id");
            }
        });
        highlightActiveNav(activeId);
    }

    // --- PRE-TEST BANNER & LOGIC ---
    // Show Pre-Test Floating Banner after 2 seconds if not completed
    if (!state.preTestCompleted) {
        setTimeout(() => {
            pretestBanner.classList.add("show");
        }, 2000);
    } else {
        updateSurveyWidgetState();
    }

    // Function to trigger Pre-test modal scroll
    window.openPreTest = function () {
        pretestBanner.classList.remove("show");
        const kampanyeSection = document.getElementById("kampanye");
        if (kampanyeSection) {
            kampanyeSection.scrollIntoView({ behavior: "smooth" });
        }
        // Visual focus on survey
        surveyWidget.style.boxShadow = "0 0 30px rgba(6, 182, 212, 0.4)";
        surveyWidget.style.borderColor = "var(--color-accent)";
        setTimeout(() => {
            surveyWidget.style.boxShadow = "var(--shadow)";
            surveyWidget.style.borderColor = "var(--border-color)";
        }, 2000);
    };

    // Pre/Post Survey Form Submission
    if (prePostForm) {
        prePostForm.addEventListener("submit", (e) => {
            e.preventDefault();

            // Calculate a dummy score based on choices for psychological evaluation (awareness)
            const q1Val = parseInt(document.querySelector('input[name="q1"]:checked').value);
            const q2Val = parseInt(document.querySelector('input[name="q2"]:checked').value);
            const q3Val = parseInt(document.querySelector('input[name="q3"]:checked').value);

            // Calculate knowledge score (correct/optimal answers give higher points)
            // q1 optimal is 4 (very understand), q2 optimal is 3 (know a lot), q3 optimal is 2 (max 2 hours)
            let score = 0;
            if (q1Val >= 3) score += 1;
            if (q2Val >= 2) score += 1;
            if (q3Val === 2) score += 1; // 2 is "Maksimal 2 jam sehari"

            if (!state.preTestCompleted) {
                // Save Pre Test
                state.preTestCompleted = true;
                state.preTestScore = score;
                localStorage.setItem(STORAGE_KEYS.PRE_TEST, score);

                // Reset form visual
                prePostForm.reset();

                // Show notification / Alert
                alert("Jawaban Pre-Test berhasil disimpan! Silakan baca edukasi dan coba kalkulator kami sebelum melakukan Post-Test.");

                updateSurveyWidgetState();
                updateDashboardStats();
            } else if (!state.postTestCompleted) {
                // Save Post Test
                state.postTestCompleted = true;
                state.postTestScore = score;
                localStorage.setItem(STORAGE_KEYS.POST_TEST, score);

                // Save to simulated database
                let surveysCount = parseInt(localStorage.getItem(STORAGE_KEYS.QUIZ_TAKEN) || 100) + 1;
                localStorage.setItem(STORAGE_KEYS.QUIZ_TAKEN, surveysCount);

                updateSurveyWidgetState();
                updateDashboardStats();
            }
        });
    }

    // Reset survey values
    window.resetSurveys = function () {
        localStorage.removeItem(STORAGE_KEYS.PRE_TEST);
        localStorage.removeItem(STORAGE_KEYS.POST_TEST);
        state.preTestCompleted = false;
        state.postTestCompleted = false;
        state.preTestScore = 0;
        state.postTestScore = 0;

        prePostForm.reset();
        updateSurveyWidgetState();

        // Scroll to campaign
        document.getElementById("kampanye").scrollIntoView({ behavior: "smooth" });
    };

    function updateSurveyWidgetState() {
        if (!state.preTestCompleted) {
            surveyStatusText.innerText = "Menunggu Pre-Test";
            surveyStatusText.className = "text-warning";
            surveySubmitBtn.innerText = "Kirim Jawaban Pre-Test";
            surveyPretestContainer.classList.remove("hidden");
            surveyCompletionBox.classList.add("hidden");
        } else if (!state.postTestCompleted) {
            surveyStatusText.innerText = "Pre-Test Selesai. Lanjutkan Post-Test!";
            surveyStatusText.className = "text-gold";
            surveySubmitBtn.innerText = "Kirim Jawaban Post-Test";
            surveyPretestContainer.classList.remove("hidden");
            surveyCompletionBox.classList.add("hidden");

            // Alter questions slightly visually or keep them to test improvement
            document.querySelector(".survey-header h3").innerText = "Post-Test Pemahaman Kampanye";
        } else {
            // Both completed
            surveyPretestContainer.classList.add("hidden");
            surveyCompletionBox.classList.remove("hidden");

            // Calculate improvement
            const preVal = state.preTestScore;
            const postVal = state.postTestScore;

            document.getElementById("score-pre-val").innerText = `${preVal}/3`;
            document.getElementById("score-post-val").innerText = `${postVal}/3`;

            const growthPill = document.getElementById("growth-pill-text");
            if (postVal > preVal) {
                growthPill.innerText = `Pemahaman Anda Meningkat! (+${(postVal - preVal) * 33}%)`;
                growthPill.className = "growth-result-pill badge-accent";
            } else if (postVal === preVal && postVal === 3) {
                growthPill.innerText = "Luar Biasa! Pemahaman Anda Sempurna (100%)";
                growthPill.className = "growth-result-pill";
            } else {
                growthPill.innerText = "Hasil Pemahaman Stabil. Terus Belajar!";
                growthPill.className = "growth-result-pill text-muted";
            }
        }
    }

    // Trigger post-test directly after quiz results
    window.triggerPostTestDirect = function () {
        document.getElementById("kampanye").scrollIntoView({ behavior: "smooth" });
        if (state.preTestCompleted && !state.postTestCompleted) {
            // Focus on post test
            alert("Silakan isi pertanyaan di bawah ini untuk menyelesaikan Post-Test Anda!");
        } else if (!state.preTestCompleted) {
            alert("Harap isi Pre-Test terlebih dahulu sebelum melakukan Post-Test agar kami bisa mencatat perkembangannya.");
        }
    };

    // --- QUIZ SYSTEM LOGIC ---
    function loadQuestion() {
        const currentQ = quizQuestions[state.currentQuizStep];

        // Update text
        quizStepText.innerText = `Pertanyaan ${state.currentQuizStep + 1} dari ${quizQuestions.length}`;
        quizCatText.innerText = `Kategori: ${currentQ.category}`;
        questionText.innerText = currentQ.question;

        // Progress bar
        const progressPercent = ((state.currentQuizStep) / quizQuestions.length) * 100;
        quizProgress.style.width = `${progressPercent === 0 ? 5 : progressPercent}%`;

        // Clear and load options
        optionsContainer.innerHTML = "";
        currentQ.options.forEach((opt, idx) => {
            const card = document.createElement("div");
            card.className = "option-card";
            if (state.quizAnswers[state.currentQuizStep] === opt.score) {
                card.classList.add("selected");
            }

            card.innerHTML = `
                <div class="option-radio"></div>
                <div class="option-text">${opt.text}</div>
            `;

            card.addEventListener("click", () => {
                // Select option
                state.quizAnswers[state.currentQuizStep] = opt.score;

                // Update visuals
                document.querySelectorAll(".option-card").forEach(c => c.classList.remove("selected"));
                card.classList.add("selected");

                // Enable next button
                nextBtn.disabled = false;
            });

            optionsContainer.appendChild(card);
        });

        // Toggle nav buttons
        prevBtn.disabled = state.currentQuizStep === 0;

        // Next button text and disabled status
        if (state.currentQuizStep === quizQuestions.length - 1) {
            nextBtn.innerText = "Lihat Hasil";
        } else {
            nextBtn.innerText = "Berikutnya";
        }

        // Disabled if no answer selected yet
        nextBtn.disabled = state.quizAnswers[state.currentQuizStep] === null;
    }

    if (prevBtn) {
        prevBtn.addEventListener("click", () => {
            if (state.currentQuizStep > 0) {
                state.currentQuizStep--;
                loadQuestion();
            }
        });
    }

    if (nextBtn) {
        nextBtn.addEventListener("click", () => {
            if (state.currentQuizStep < quizQuestions.length - 1) {
                state.currentQuizStep++;
                loadQuestion();
            } else {
                // Finish quiz
                showQuizResults();
            }
        });
    }

    function showQuizResults() {
        quizBody.classList.add("hidden");
        quizFooter.classList.add("hidden");
        quizResults.classList.remove("hidden");

        // Calculate Score
        const totalScore = state.quizAnswers.reduce((sum, score) => sum + (score || 0), 0);

        // Update Local Storage
        let quizCounts = parseInt(localStorage.getItem(STORAGE_KEYS.QUIZ_TAKEN) || 150) + 1;
        let quizScoreTotal = parseInt(localStorage.getItem(STORAGE_KEYS.QUIZ_TOTAL_SCORE) || 1500) + totalScore;
        localStorage.setItem(STORAGE_KEYS.QUIZ_TAKEN, quizCounts);
        localStorage.setItem(STORAGE_KEYS.QUIZ_TOTAL_SCORE, quizScoreTotal);

        // Render result elements
        const scoreNumEl = document.getElementById("result-score");
        const severityBadge = document.getElementById("result-severity-badge");
        const summaryText = document.getElementById("result-text-summary");
        const recList = document.getElementById("recommendations-list");
        const scoreCircle = document.querySelector(".score-circle");

        scoreNumEl.innerText = totalScore;
        recList.innerHTML = "";

        // Reset classes
        scoreCircle.className = "score-circle";

        // Determine Level
        if (totalScore <= 6) {
            // Low Risk
            severityBadge.innerText = "Tingkat Rendah (Safe Player)";
            severityBadge.className = "result-badge badge-low";
            scoreCircle.classList.add("low");
            summaryText.innerHTML = `<strong>Selamat!</strong> Pola bermain Anda tergolong sehat. Anda mampu membatasi waktu bermain Mobile Legends dan tetap menyeimbangkan tanggung jawab di dunia nyata.`;

            const recs = [
                "Pertahankan durasi bermain maksimal 1-2 jam per hari.",
                "Teruskan melakukan mabar hanya di akhir pekan sebagai sarana rekreasi.",
                "Bantu teman satu tim Anda untuk menyadari pentingnya membatasi waktu mabar."
            ];
            recs.forEach(r => recList.innerHTML += `<li>${r}</li>`);
        } else if (totalScore <= 13) {
            // Mid Risk
            severityBadge.innerText = "Tingkat Sedang (Peringatan / Warning)";
            severityBadge.className = "result-badge badge-mid";
            scoreCircle.classList.add("mid");
            summaryText.innerHTML = `<strong>Perhatian!</strong> Anda mulai menunjukkan gejala adiksi. Bermain Mobile Legends sudah mulai mengganggu konsentrasi belajar, jam tidur, atau emosi harian Anda.`;

            const recs = [
                "Batasi waktu bermain maksimal 2 game sekali duduk, atau maksimal 2 jam sehari.",
                "Terapkan aturan '2-Loss Stop Rule' (berhenti main setelah kalah 2 kali beruntun).",
                "Nonaktifkan notifikasi game di jam produktif kuliah/sekolah.",
                "Cari hobi fisik atau alternatif rekreasi lain di luar gawai."
            ];
            recs.forEach(r => recList.innerHTML += `<li>${r}</li>`);
        } else {
            // High Risk
            severityBadge.innerText = "Tingkat Tinggi (Kecenderungan Adiksi)";
            severityBadge.className = "result-badge badge-high";
            scoreCircle.classList.add("high");
            summaryText.innerHTML = `<strong>Peringatan Keras!</strong> Hubungan Anda dengan Mobile Legends sudah berada dalam kategori berisiko adiksi tinggi. Game ini mendominasi pikiran, mengganggu relasi sosial, merusak jam tidur, dan mengabaikan perkuliahan Anda.`;

            const recs = [
                "Lakukan detoks digital: uninstall Mobile Legends selama 3 hingga 7 hari.",
                "Gunakan aplikasi pembatas waktu aplikasi (App Timer) dan kunci game Anda setelah 1 jam.",
                "Jangan meletakkan HP di dekat kasur menjelang tidur agar tidak memicu push rank malam.",
                "Ceritakan kondisi Anda kepada sahabat dekat atau keluarga untuk membantu mengawasi.",
                "Jika sulit mengontrolnya sendiri, konsultasikan ke layanan konseling atau psikolog kampus."
            ];
            recs.forEach(r => recList.innerHTML += `<li>${r}</li>`);
        }

        // Suggest post test if pretest is already taken
        const postTestBtnSuggest = document.getElementById("posttest-btn-suggest");
        if (state.preTestCompleted && !state.postTestCompleted) {
            postTestBtnSuggest.classList.remove("hidden");
        } else {
            postTestBtnSuggest.classList.add("hidden");
        }

        updateDashboardStats();
    }

    window.resetQuiz = function () {
        state.quizAnswers = Array(10).fill(null);
        state.currentQuizStep = 0;

        quizBody.classList.remove("hidden");
        quizFooter.classList.remove("hidden");
        quizResults.classList.add("hidden");

        loadQuestion();
    };

    // Load initial question
    loadQuestion();

    // --- SCREEN TIME CALCULATOR ---
    window.calculateMetrics = function () {
        const hoursInput = parseFloat(document.getElementById("calc-hours").value) || 0;
        const moneyInput = parseFloat(document.getElementById("calc-money").value) || 0;

        if (hoursInput < 0 || moneyInput < 0) {
            alert("Harap masukkan nilai positif!");
            return;
        }

        const resultsPanel = document.getElementById("calc-results");
        resultsPanel.classList.remove("hidden");

        // Calculations (annual)
        const totalHoursYear = Math.round(hoursInput * 365);
        const totalDaysYear = (totalHoursYear / 24).toFixed(1);
        const totalMoneyYear = moneyInput * 12;

        // Alternatives calculation
        // Asumsi: 1 buku dibaca dalam 5 jam
        const booksCount = Math.round(totalHoursYear / 5);
        // Asumsi: 1 skill dasar dipelajari dalam 20 jam
        const skillsCount = Math.round(totalHoursYear / 20);
        // Asumsi: buku kuliah seharga Rp 150.000
        const textbooksCount = Math.round(totalMoneyYear / 150000);

        // Injeksi nilai ke DOM
        document.getElementById("calc-res-hours").innerText = `${totalHoursYear.toLocaleString()} Jam`;
        document.getElementById("calc-res-days").innerText = `(Setara ${totalDaysYear} Hari Penuh)`;
        document.getElementById("calc-res-money").innerText = `Rp ${totalMoneyYear.toLocaleString("id-ID")}`;

        document.getElementById("alt-books").innerText = `${booksCount} Buku`;
        document.getElementById("alt-skills").innerText = `${skillsCount} Keterampilan`;
        document.getElementById("alt-goods").innerText = `${textbooksCount} Buku Kuliah`;
        document.getElementById("alt-sleep").innerText = `${totalHoursYear.toLocaleString()} Jam`;

        // Smooth scroll to see the results
        resultsPanel.scrollIntoView({ behavior: "smooth", block: "nearest" });
    };

    // --- ACCORDION GEJALA LOGIC ---
    const accordionHeaders = document.querySelectorAll(".accordion-header");
    accordionHeaders.forEach(header => {
        header.addEventListener("click", () => {
            const item = header.parentElement;
            const content = header.nextElementSibling;

            // Close other items
            document.querySelectorAll(".accordion-item").forEach(otherItem => {
                if (otherItem !== item && otherItem.classList.contains("active")) {
                    otherItem.classList.remove("active");
                    otherItem.querySelector(".accordion-content").style.maxHeight = null;
                }
            });

            // Toggle current
            item.classList.toggle("active");
            if (item.classList.contains("active")) {
                content.style.maxHeight = content.scrollHeight + "px";
            } else {
                content.style.maxHeight = null;
            }
        });
    });

    // --- BLOG FILTERS & MODAL ---
    // Category Filtering
    filterButtons.forEach(btn => {
        btn.addEventListener("click", () => {
            // Remove active class
            filterButtons.forEach(b => b.classList.remove("active"));
            btn.classList.add("active");

            const category = btn.getAttribute("data-category");

            blogCards.forEach(card => {
                const cardCat = card.getAttribute("data-category");
                if (category === "all" || cardCat === category) {
                    card.style.display = "flex";
                } else {
                    card.style.display = "none";
                }
            });
        });
    });

    // Modal Control
    window.openBlogModal = function (id) {
        const article = blogArticles[id];
        if (!article) return;

        modalBody.innerHTML = `
            <div class="modal-article-header">
                <span class="badge">${article.category}</span>
                <h2>${article.title}</h2>
                <div class="modal-article-meta">
                    <span>Oleh: Tim Cyberpsychology</span>
                    <span>•</span>
                    <span>Diterbitkan: ${article.date}</span>
                </div>
            </div>
            <div class="modal-article-body">
                ${article.content}
            </div>
        `;

        blogModal.classList.add("open");
        document.body.style.overflow = "hidden"; // Disable background scrolling
    };

    window.closeBlogModal = function () {
        blogModal.classList.remove("open");
        document.body.style.overflow = "auto";
    };

    // Close modal on click outside
    window.addEventListener("click", (e) => {
        if (e.target === blogModal) {
            closeBlogModal();
        }
    });

    // --- RATING STAR CONTROL ---
    function setupStars(starsElement, ratingInput) {
        starsElement.forEach(star => {
            star.addEventListener("click", () => {
                const value = parseInt(star.getAttribute("data-value"));
                ratingInput.value = value;

                // Highlight stars
                starsElement.forEach(s => {
                    const sVal = parseInt(s.getAttribute("data-value"));
                    if (sVal <= value) {
                        s.classList.add("active");
                    } else {
                        s.classList.remove("active");
                    }
                });
            });
        });
    }

    setupStars(uiStars, uiRatingInput);
    setupStars(contentStars, contentRatingInput);

    // --- EVALUATION FORM SUBMISSION ---
    if (evalForm) {
        evalForm.addEventListener("submit", (e) => {
            e.preventDefault();

            const name = document.getElementById("eval-name").value.trim() || "Anonim";
            const uiVal = parseInt(uiRatingInput.value);
            const contentVal = parseInt(contentRatingInput.value);
            const comment = document.getElementById("eval-comment").value.trim();

            if (uiVal === 0 || contentVal === 0) {
                alert("Harap berikan rating bintang untuk UI/UX dan Konten!");
                return;
            }

            // Create feedback object
            const newFeedback = {
                name: name,
                ui: uiVal,
                content: contentVal,
                comment: comment
            };

            // Get existing feedback list from DB
            let currentList = JSON.parse(localStorage.getItem(STORAGE_KEYS.FEEDBACK)) || [];
            currentList.unshift(newFeedback); // Insert at start
            localStorage.setItem(STORAGE_KEYS.FEEDBACK, JSON.stringify(currentList));

            // Reset form
            evalForm.reset();
            uiStars.forEach(s => s.classList.remove("active"));
            contentStars.forEach(s => s.classList.remove("active"));
            uiRatingInput.value = 0;
            contentRatingInput.value = 0;

            alert("Terima kasih atas tanggapan evaluasi Anda! Feedback telah dicatat.");

            // Update DOM
            renderFeedbackList();
            updateDashboardStats();

            // Scroll to dashboard
            document.getElementById("dashboard").scrollIntoView({ behavior: "smooth" });
        });
    }

    // --- DASHBOARD RENDER LOGIC ---
    function renderFeedbackList() {
        const feedbackListEl = document.getElementById("feedback-list");
        if (!feedbackListEl) return;

        const list = JSON.parse(localStorage.getItem(STORAGE_KEYS.FEEDBACK)) || [];
        feedbackListEl.innerHTML = "";

        list.forEach(item => {
            const card = document.createElement("div");
            card.className = "feedback-card";

            // Generate star characters
            const uiStarsStr = "★".repeat(item.ui) + "☆".repeat(5 - item.ui);
            const contentStarsStr = "★".repeat(item.content) + "☆".repeat(5 - item.content);

            card.innerHTML = `
                <div class="feedback-card-header">
                    <span class="feedback-name">${item.name}</span>
                    <div class="feedback-ratings">
                        <span>UI/UX: <strong class="text-gold">${uiStarsStr}</strong></span>
                        <span>Konten: <strong class="text-gold">${contentStarsStr}</strong></span>
                    </div>
                </div>
                <p class="feedback-comment">${item.comment}</p>
            `;
            feedbackListEl.appendChild(card);
        });
    }

    function updateDashboardStats() {
        // Elements
        const pageviewsVal = document.getElementById("dash-pageviews");
        const quizzesVal = document.getElementById("dash-quizzes");
        const avgAddictionVal = document.getElementById("dash-avg-addiction");
        const avgRatingVal = document.getElementById("dash-avg-rating");
        const ratingCountVal = document.getElementById("dash-rating-count");
        const addictionSeverityText = document.getElementById("dash-addiction-severity");
        const userStatusQuizzes = document.getElementById("dash-user-status-quizzes");

        // Values from localStorage
        const views = localStorage.getItem(STORAGE_KEYS.PAGEVIEWS) || 1248;
        const quizzes = parseInt(localStorage.getItem(STORAGE_KEYS.QUIZ_TAKEN)) || 342;
        const quizScoresTotal = parseInt(localStorage.getItem(STORAGE_KEYS.QUIZ_TOTAL_SCORE)) || 3898;

        // Calculate average addiction score
        const avgScore = (quizScoresTotal / quizzes).toFixed(1);

        // Calculate feedback averages
        const feedbacks = JSON.parse(localStorage.getItem(STORAGE_KEYS.FEEDBACK)) || [];
        let uiTotal = 0;
        let contentTotal = 0;
        feedbacks.forEach(f => {
            uiTotal += f.ui;
            contentTotal += f.content;
        });
        const avgUi = feedbacks.length > 0 ? (uiTotal / feedbacks.length) : 5.0;
        const avgContent = feedbacks.length > 0 ? (contentTotal / feedbacks.length) : 5.0;
        const totalAvg = ((avgUi + avgContent) / 2).toFixed(1);

        // Update HTML
        if (pageviewsVal) pageviewsVal.innerText = parseInt(views).toLocaleString();
        if (quizzesVal) quizzesVal.innerText = quizzes;
        if (avgAddictionVal) avgAddictionVal.innerText = `${avgScore} / 20`;
        if (avgRatingVal) avgRatingVal.innerText = `${totalAvg} / 5.0`;
        if (ratingCountVal) ratingCountVal.innerText = `Dari ${feedbacks.length} Responden`;

        // Update addiction severity description
        if (addictionSeverityText) {
            if (avgScore <= 6) {
                addictionSeverityText.innerText = "Tingkat Rendah (Aman)";
                addictionSeverityText.className = "dash-sub text-cyan";
            } else if (avgScore <= 13) {
                addictionSeverityText.innerText = "Tingkat Sedang (Peringatan)";
                addictionSeverityText.className = "dash-sub text-gold";
            } else {
                addictionSeverityText.innerText = "Tingkat Tinggi (Adiksi)";
                addictionSeverityText.className = "dash-sub text-danger";
            }
        }

        // Update User Quiz Status
        if (userStatusQuizzes) {
            const hasTaken = state.quizAnswers.every(v => v !== null);
            if (hasTaken) {
                const totalScore = state.quizAnswers.reduce((sum, score) => sum + (score || 0), 0);
                userStatusQuizzes.innerText = `Skor Anda: ${totalScore}/20 (Tercatat!)`;
                userStatusQuizzes.className = "dash-sub text-cyan";
            } else {
                userStatusQuizzes.innerText = "Skor Anda belum tercatat (Ambil tes)";
                userStatusQuizzes.className = "dash-sub";
            }
        }
    }

    // Share Campaign Link
    window.shareLink = function () {
        const url = window.location.href;
        navigator.clipboard.writeText(url).then(() => {
            alert("Link website kampanye berhasil disalin ke clipboard! Bagikan ke grup kelas Anda.");
        }).catch(err => {
            console.error("Gagal menyalin link: ", err);
        });
    };

    // --- RANK-STRESS MATRIX LOGIC ---
    const rankSelectBtns = document.querySelectorAll(".rank-select-btn");
    const rankDiagDisplay = document.getElementById("rank-diagnosis-display");

    function renderRankDiagnosis(rankKey) {
        if (!rankDiagDisplay) return;
        const data = rankStressData[rankKey];
        if (!data) return;

        rankDiagDisplay.innerHTML = `
            <div class="diag-header">
                <span class="diag-rank-title text-cyan">${data.title}</span>
                <span class="diag-stress-level ${data.stressClass}">Tingkat Stres: ${data.stressLevel}</span>
            </div>
            <div class="diag-body">
                <h4>1. Deskripsi Perilaku & Emosi:</h4>
                <p>${data.description}</p>
                
                <h4>2. Beban Kognitif & Mental:</h4>
                <p>${data.cognitiveLoad}</p>
                
                <h4>3. Rekomendasi / Saran Klinis Cyberpsychology:</h4>
                <ul class="diag-tips">
                    <li>${data.advice}</li>
                    <li>Evaluasi durasi bermain mingguan Anda secara jujur menggunakan kalkulator di bawah.</li>
                    <li>Ingatlah untuk selalu memprioritaskan kesehatan fisik, waktu tidur, dan relasi sosial di dunia nyata.</li>
                </ul>
            </div>
        `;
    }

    if (rankSelectBtns.length > 0) {
        rankSelectBtns.forEach(btn => {
            btn.addEventListener("click", () => {
                rankSelectBtns.forEach(b => b.classList.remove("active"));
                btn.classList.add("active");
                const rank = btn.getAttribute("data-rank");
                renderRankDiagnosis(rank);
            });
        });

        // Load initial casual rank diagnosis
        renderRankDiagnosis("casual");
    }

    // --- SCROLL REVEAL ANIMATIONS (INTERSECTION OBSERVER) & SNAP CONTROLLER ---
    // Setup stagger animation delays dynamically
    document.querySelectorAll("section, footer").forEach(sec => {
        const revealItems = sec.querySelectorAll(
            ".section-header, .edu-card, .rank-selectors, .rank-diagnosis-card, .quiz-container, .tip-card, .calculator-card, .blog-card, .kampanye-grid > div, .dashboard-grid > div"
        );
        revealItems.forEach((item, idx) => {
            item.style.setProperty("--delay", `${idx * 150}ms`);
        });
    });

    // Inject scroll-reveal class to section containers and footer container dynamically
    document.querySelectorAll("section .container, footer .footer-container").forEach(el => {
        el.classList.add("scroll-reveal");
    });

    const revealElements = document.querySelectorAll(".scroll-reveal");
    const revealObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add("revealed");
                observer.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.05,
        rootMargin: "0px 0px -30px 0px"
    });

    revealElements.forEach(el => {
        revealObserver.observe(el);
    });

    // Immediately reveal any elements already visible on page load (e.g. hero section)
    revealElements.forEach(el => {
        const rect = el.getBoundingClientRect();
        if (rect.top < window.innerHeight && rect.bottom > 0) {
            el.classList.add("revealed");
            revealObserver.unobserve(el);
        }
    });

    // Find current active section based on scroll position
    function updateCurrentSectionIndex() {
        if (isAnimating) return;
        const scrollY = window.pageYOffset;
        for (let i = sections.length - 1; i >= 0; i--) {
            if (scrollY >= sections[i].offsetTop - 10) {
                currentSectionIndex = i;
                break;
            }
        }
    }

    window.addEventListener("scroll", updateCurrentSectionIndex);
    window.addEventListener("resize", updateCurrentSectionIndex);
    updateCurrentSectionIndex();

    // Set correct nav highlight on initial load
    highlightNavFromScroll();

    // Snap to a section smoothly
    function scrollToSection(index) {
        isAnimating = true;
        currentSectionIndex = index;
        const targetSection = sections[index];
        const targetY = targetSection.offsetTop;

        // Sync nav active state immediately
        const targetId = targetSection.getAttribute("id");
        highlightActiveNav(targetId);

        smoothScrollTo(targetY, 1000);

        setTimeout(() => {
            isAnimating = false;
            highlightNavFromScroll();
        }, 1050);
    }

    // Wheel snap controller — velocity-based, smooth and natural
    let lastWheelTime = 0;
    let wheelCooldown = false;

    window.addEventListener("wheel", (e) => {
        if (window.innerWidth <= 1024) return;

        // Allow scrolling inside overflow elements (modals, lists, etc.)
        const path = e.composedPath() || [];
        for (let i = 0; i < path.length; i++) {
            const el = path[i];
            if (el === document.body || el === document.documentElement) break;
            if (el.scrollHeight > el.clientHeight) {
                const scrollTop = el.scrollTop;
                const maxScroll = el.scrollHeight - el.clientHeight;
                if ((e.deltaY > 0 && scrollTop < maxScroll) || (e.deltaY < 0 && scrollTop > 0)) {
                    return;
                }
            }
        }

        e.preventDefault();
        if (isAnimating || wheelCooldown) return;

        // Only react to intentional scroll gestures (filter trackpad micro-movements)
        if (Math.abs(e.deltaY) < 5) return;

        const now = Date.now();
        if (now - lastWheelTime < 120) return; // natural cooldown between triggers
        lastWheelTime = now;

        const scrollY = window.pageYOffset;
        const viewH = window.innerHeight;
        const currentSection = sections[currentSectionIndex];

        if (e.deltaY > 0) {
            // Scrolling DOWN
            const sectionBottom = currentSection.offsetTop + currentSection.offsetHeight;
            const remainingBelow = sectionBottom - (scrollY + viewH);

            if (remainingBelow > 80) {
                // Reveal more of current section smoothly
                wheelCooldown = true;
                smoothScrollTo(scrollY + viewH * 0.75, 600);
                setTimeout(() => { wheelCooldown = false; }, 650);
            } else if (currentSectionIndex < sections.length - 1) {
                scrollToSection(currentSectionIndex + 1);
            }
        } else {
            // Scrolling UP
            const remainingAbove = scrollY - currentSection.offsetTop;

            if (remainingAbove > 80) {
                // Scroll back up within current section
                wheelCooldown = true;
                smoothScrollTo(scrollY - viewH * 0.75, 600);
                setTimeout(() => { wheelCooldown = false; }, 650);
            } else if (currentSectionIndex > 0) {
                scrollToSection(currentSectionIndex - 1);
            }
        }
    }, { passive: false });

    // Keyboard snap controller (Desktop only)
    window.addEventListener("keydown", (e) => {
        if (window.innerWidth <= 1024) return;
        if (["ArrowDown", "PageDown"].includes(e.key)) {
            e.preventDefault();
            if (currentSectionIndex < sections.length - 1) scrollToSection(currentSectionIndex + 1);
        } else if (["ArrowUp", "PageUp"].includes(e.key)) {
            e.preventDefault();
            if (currentSectionIndex > 0) scrollToSection(currentSectionIndex - 1);
        }
    });

    // Render Dashboard initially
    renderFeedbackList();
    updateDashboardStats();
});